# BÁO CÁO RÀ SOÁT TUÂN THỦ PHÁP LÝ AI (AI COMPLIANCE AUDIT V2)
**Sản phẩm rà soát:** TrustGuard
**Ngày rà soát:** 11/05/2026
**Vai trò:** Chuyên viên Tuân thủ pháp lý AI

Dựa trên Luật AI VN (134/2025/QH15), Luật BVDLCN (91/2025/QH15) và Bộ luật Hình sự VN, dưới đây là 7 vi phạm pháp lý tiềm năng của TrustGuard, được đối chiếu với các án lệ/pattern thực tế tại Việt Nam.

---

### VI PHẠM 1: Marketing thổi phồng về "tự động hóa hoàn toàn"
- **Luật áp dụng:** Bộ luật Hình sự VN
- **Điều:** Khoản 2 Điều 198 (Lừa dối khách hàng - ACV $50k > mức 50 triệu đồng)
- **Bằng chứng trong sản phẩm:** TrustGuard claim *"Thay thế quy trình 'giấy tờ' của phòng Pháp chế"* và *"tự động hóa luồng ra quyết định GO/NO-GO cho Executive"*.
- **Pattern khớp với:** Vụ kẹo Kera 11/2025 (Cam kết tính năng thay thế 100% nhưng thực tế không kiểm soát được các rủi ro pháp lý phức tạp của doanh nghiệp).
- **Hành động sửa:** 
  1. Gỡ chữ "Thay thế", đổi thành "Hỗ trợ số hóa quy trình pháp chế". 
  2. Sửa "tự động hóa quyết định" thành "tự động hóa khâu đề xuất quyết định". 
  3. Thêm disclaimer (SLA) vào hợp đồng: TrustGuard chỉ mang tính chất tham khảo, CISO là người chịu trách nhiệm cuối.
- **Deadline:** Khắc phục ngay trong tuần này trên Landing Page và Pitch Deck.

### VI PHẠM 2: Thổi phồng ROI không có evidence quy mô lớn
- **Luật áp dụng:** Bộ luật Hình sự VN
- **Điều:** Khoản 2 Điều 198
- **Bằng chứng trong sản phẩm:** Claim *"giảm 80% thời gian phê duyệt (từ 10 ngày xuống 2 ngày)"* và *"duyệt nhanh gấp 5 lần"*.
- **Pattern khớp với:** Vụ kẹo Kera (Tuyên bố "1 viên kẹo = 1 đĩa rau" không có data kiểm chứng A/B test độc lập, chỉ dựa trên quy mô pilot hẹp).
- **Hành động sửa:** 
  1. Thêm footnote rõ ràng "Dựa trên kết quả Pilot của các dự án cấu trúc đơn giản tại 3 tập đoàn". 
  2. Không cam kết mức giảm 80% như một tính năng bắt buộc cho tất cả khách hàng. 
  3. Lưu lại toàn bộ log file chứng minh của 3 dự án Pilot làm bằng chứng (Hồ sơ kiểm thử claim).
- **Deadline:** Sửa văn phong ngay lập tức.

### VI PHẠM 3: Claim vượt quá năng lực bảo mật kỹ thuật
- **Luật áp dụng:** Bộ luật Hình sự VN
- **Điều:** Khoản 2 Điều 198
- **Bằng chứng trong sản phẩm:** Cam kết *"Phân tích log theo thời gian thực (real-time) để quét dữ liệu nhạy cảm (PII)"*.
- **Pattern khớp với:** Vụ kẹo Kera (Thổi phồng tính năng. LLM API gửi đi nước ngoài có độ trễ và tỷ lệ hallucination nhất định, không bao giờ đạt được 100% real-time security).
- **Hành động sửa:** 
  1. Đổi "Thời gian thực" thành "Gần thời gian thực (Near real-time)". 
  2. Công bố rõ tỷ lệ chính xác (Accuracy/Recall) của bộ lọc PII. 
  3. Cập nhật vào Terms of Service (ToS) rằng tool có thể có độ trễ API do Rate limit.
- **Deadline:** Trong tuần này.

### VI PHẠM 4: Rò rỉ dữ liệu cá nhân qua API ngoại (Thiếu Security by Design)
- **Luật áp dụng:** Luật Bảo vệ dữ liệu cá nhân (PDPL)
- **Điều:** Điều 30 (Kiểm soát bảo mật từ thiết kế) và Điều 8 (Phạt đến 5% doanh thu)
- **Bằng chứng trong sản phẩm:** Tính năng *"tự động phân tích log đa mô hình (OpenAI, Claude, Custom AI)"*. Đẩy log chứa lượng lớn PII của user nội bộ thẳng lên public API của hãng thứ 3.
- **Pattern khớp với:** Vụ rò rỉ CIC 9/2025 (Kỹ sư đẩy raw data chứa PII lên ChatGPT gây rò rỉ bảo mật).
- **Hành động sửa:** 
  1. Deploy ngay 1 module "Data Scrubber/Masking" cục bộ để mã hóa/xóa PII trước khi gọi API OpenAI/Claude. 
  2. Không lưu trữ log raw chứa PII trên database trung gian của TrustGuard. 
  3. Chuyển hẳn sang plan fallback "Llama 3 On-premise" cho các khách hàng khắt khe.
- **Deadline:** Đã quá hạn (Luật hiệu lực 1/1/2026) -> Vá ngay lập tức trước khi chốt hợp đồng.

### VI PHẠM 5: Thiếu Đánh giá tác động chuyển dữ liệu ra nước ngoài (CTIA)
- **Luật áp dụng:** Luật BVDLCN (PDPL)
- **Điều:** Điều 30
- **Bằng chứng trong sản phẩm:** Sử dụng *"API xử lý log (GPT-4o mini, Claude)"* và host trên *"Server/Cloud (Azure/AWS)"*. Dữ liệu sinh ra tại VN bay qua server quốc tế.
- **Pattern khớp với:** Vụ rò rỉ CIC (Chia sẻ, chuyển dữ liệu ra nước ngoài thiếu báo cáo).
- **Hành động sửa:** 
  1. Lập 1 bộ hồ sơ CTIA (Đánh giá tác động chuyển dữ liệu ra nước ngoài). 
  2. Nộp lên cổng của Bộ Công an. 
  3. Đảm bảo có Data Processing Agreement (DPA) ký với OpenAI/AWS.
- **Deadline:** Nộp trong vòng 60 ngày kể từ ngày bắt đầu luồng log đầu tiên.

### VI PHẠM 6: Thiếu Đánh giá & Đăng ký Hệ thống AI Tầng Cao
- **Luật áp dụng:** Luật AI Việt Nam 134/2025/QH15
- **Điều:** Điều 9 (Phân loại và giám sát hệ thống AI rủi ro)
- **Bằng chứng trong sản phẩm:** Tính năng *"tự động hóa luồng ra quyết định GO/NO-GO cho Executive"*. Khách hàng mục tiêu là "tập đoàn lớn" (rất có thể bao gồm Ngân hàng, Y tế). AI can thiệp vào quyết định kiểm duyệt của tổ chức tài chính/y tế là AI Tầng Cao.
- **Pattern khớp với:** Kera (Không đánh giá phân loại rủi ro đầu vào trước khi lưu hành).
- **Hành động sửa:** 
  1. Phân loại TrustGuard là AI Tầng Cao nếu triển khai cho Finance/Healthcare. 
  2. Đăng ký CSDL AI Quốc gia với Bộ KH&CN. 
  3. Bổ sung cơ chế "Human in the loop" bắt buộc: AI chỉ chấm Trust Score, CISO là người click nút GO cuối cùng.
- **Deadline:** 1/3/2026 (hoặc 1/3/2027 nếu chưa chạm khối Finance/Healthcare theo thời gian ân hạn).

### VI PHẠM 7: Tiếp tay cho "Shadow AI" tội phạm (Vendor Risk)
- **Luật áp dụng:** Bộ luật Hình sự VN
- **Điều:** Điều 324 (Rửa tiền) hoặc Điều 174 (Tiếp tay lừa đảo)
- **Bằng chứng trong sản phẩm:** Tính năng *"Fast-track duyệt tự động cho dự án AI rủi ro thấp"*. Nếu AI đó không vi phạm PII (rủi ro thấp về data) nhưng lại có luồng Use Case lừa đảo/spam tiền ảo, TrustGuard cấp "GO" đồng nghĩa tiếp tay.
- **Pattern khớp với:** Vụ Mr Pips 2/2026 (Shark Bình xử lý thanh toán cho sàn lừa đảo, nhắm mắt làm ngơ vì muốn hưởng phí $50k/năm).
- **Hành động sửa:** 
  1. Lập "Nhật ký giám sát hành vi bất thường" (Abuse log). 
  2. Nâng cấp AI để quét thêm "Toxic/Scam Use Case" thay vì chỉ quét PII. 
  3. Thiết lập quyền Auto-block hoặc từ chối cấp dịch vụ cho Tenant nếu phát hiện hành vi phạm tội (Báo cáo thẳng cơ quan chức năng).
- **Deadline:** Ngay tuần này (Lập template giám sát hành vi).
