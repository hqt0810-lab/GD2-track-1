# Territorial Scope — TrustGuard
**Date:** 08/05/2026

## Câu hỏi 1: User EU?
- Có user EU hiện tại: 0 (Khách hàng là 3 tập đoàn lớn tại Việt Nam như VinHomes).
- Kế hoạch mở rộng EU 12 tháng tới: KHÔNG (Theo Market Analysis, dự án đang focus vào thị trường Việt Nam & SEA).
- **Kết luận:** EU AI Act áp dụng = **KHÔNG**.

## Câu hỏi 2: Dữ liệu Việt Nam?
### Loại dữ liệu cá nhân đang xử lý:
1. **Tên / Email / ID nhân viên:** Trích xuất từ log hệ thống của khách hàng doanh nghiệp.
2. **Hành vi sử dụng:** Lịch sử câu prompt, tần suất dùng AI (Shadow AI) của nhân viên.
3. **Dữ liệu nhạy cảm (PII):** Các thông tin của khách hàng (SĐT, Email, CMND, tài chính...) vô tình bị leak vào trong log prompt.
4. **Vị trí (IP Address):** Từ log truy cập của developer.
5. **Thông tin thiết bị / Session:** Từ hệ thống Observability (Datadog, LangSmith).

### Có chuyển ra nước ngoài: 
- **CÓ**. TrustGuard đang sử dụng API của các model AI nước ngoài (OpenAI GPT-4o mini, Claude) và hệ thống Cloud quốc tế (AWS/Azure) để xử lý log.

### Kết luận: 
- **PDPL áp dụng = YES** (Gần như chắc chắn vì xử lý dữ liệu của công dân Việt Nam).
- **Đánh giá tác động chuyển dữ liệu ra nước ngoài (CTIA) = YES** (Bắt buộc phải nộp do gọi API ngoại).

## Câu hỏi 3: Tầng rủi ro Luật AI VN?
- **Phân loại:** **Thấp** (Mặc định) hoặc **Cao** (Tùy tệp khách hàng).
- **Lập luận:** 
  - Về bản chất, TrustGuard là phần mềm nội bộ (B2B SaaS) tự động hóa quét log và chấm điểm rủi ro, không trực tiếp ra quyết định tác động đến quyền lợi người tiêu dùng $\rightarrow$ thuộc tầng **Thấp**. 
  - *Tuy nhiên*, nếu khách hàng của TrustGuard là các Ngân hàng hoặc tổ chức Tài chính/Y tế, và TrustGuard dùng AI để trực tiếp auto GO/NO-GO dự án của họ, hệ thống này có thể bị liên đới xếp vào tầng **Cao**.
- **Nghĩa vụ tương ứng:** Tự nguyện công khai tính năng AI (nếu Thấp). Nếu triển khai cho Ngân hàng (Cao), phải thực hiện đánh giá sự phù hợp và có cơ chế con người can thiệp vào quyết định GO/NO-GO.

## 4 deadlines đã note vào Notion
- [x] **1/1/2026** — PDPL (Nghị định bảo vệ dữ liệu cá nhân) hiệu lực (đã qua).
- [x] **1/3/2026** — Luật AI VN hiệu lực (đã qua).
- [ ] **2/8/2026** — EU AI Act high-risk hiệu lực đầy đủ (dù chưa áp dụng nhưng cần note để theo dõi).
- [ ] **1/3/2027** — Hết ân hạn (cho startup non-health/edu/finance).
