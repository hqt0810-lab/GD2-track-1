# Marketing Claims Audit — Kẹo Kera (CER Group)

**Ngày rà soát:** Tháng 2/2025 (Giả định)
**Người rà soát:** Quang Linh Vlogs

## Bảng rà soát 4 cột

| Câu gốc (Từ Livestream) | Mức | Evidence (Thực tế) | Honest version (Phiên bản trung thực) |
|---|---|---|---|
| *"1 viên kẹo này tương đương 1 đĩa rau luộc."* | **C** (Thổi phồng) | Mỗi viên chỉ chứa 0.03g chất xơ (0.935%). Không có data chứng minh tương đương 1 đĩa rau. | *"Mỗi viên kẹo có bổ sung một lượng nhỏ bột chiết xuất từ rau củ (cải bó xôi, rau má...), là món ăn vặt hỗ trợ thêm."* |
| *"Một ngày chỉ cần ăn 2-3 viên là đủ chất xơ cho người bình thường."* | **C** (Thổi phồng) | 2-3 viên chỉ cung cấp < 0.1g chất xơ. Nền sản phẩm 70% là sorbitol syrup và đường. | *"Kẹo Kera là món ăn vặt mang vị rau củ. Bạn vẫn cần đảm bảo cung cấp đủ lượng rau xanh thực tế trong khẩu phần ăn mỗi ngày."* |
| *"Sản phẩm có thể thay rau xanh trong bữa ăn cho cả trẻ nhỏ."* | **C** (Thổi phồng) | Sản phẩm chủ yếu là đường, gelatin, phụ gia tạo gel. Không chứa đủ vitamin/chất xơ để thay thế rau xanh. | *"Kẹo Kera là món ăn vặt vị rau củ dễ ăn cho trẻ nhỏ. Khuyến khích ba mẹ vẫn duy trì chế độ ăn rau tươi cho bé."* |

## Tự kiểm tra (Bước 4)
- **Trang giới thiệu/Livestream mới có còn convert được không?** 
  - Khả năng chuyển đổi (convert) chắc chắn sẽ **giảm mạnh**. Vì sản phẩm lúc này được trả về đúng bản chất là "kẹo ăn vặt vị rau củ", không còn tính năng "thần kỳ" thay thế được rau xanh. 
  - Tuy nhiên, sự đánh đổi này là **bắt buộc** để tránh vi phạm Điều 198 Bộ luật Hình sự (Lừa dối khách hàng).
  - Vấn đề cốt lõi không phải ở "câu marketing kém", mà là chất lượng sản phẩm thực tế (product) không đáp ứng được giá trị đề ra.
