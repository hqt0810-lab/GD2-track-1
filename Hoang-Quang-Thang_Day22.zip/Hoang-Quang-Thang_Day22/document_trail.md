# Document Trail — TrustGuard (Hồ sơ chứng cứ Founder)
**Date:** 08/05/2026
**Tư duy rà soát:** "Bảo hiểm pháp lý dạng tài liệu thật" (Áp dụng mindset của Case Shark Bình/Ngân Lượng: Phải chứng minh được mình đã thẩm định, không làm ngơ trước vi phạm để hưởng lợi).

## 1. Bảng đối chiếu 5 loại hồ sơ

| # | Loại hồ sơ | Mục đích | Status (✓ / ✗) | Link/Path (nếu có) hoặc Deadline build |
|---|---|---|---|---|
| 1 | Nhật ký kiểm thử claim AI | Chống Điều 198 BLHS (Case Kera) | ✗ CHƯA có | Build trước đợt Launch sản phẩm Q3/2026. |
| 2 | Hồ sơ rà soát điều khoản vendor | Chống vendor risk | ✗ CHƯA có | Hoàn thành trước 15/05/2026 (Rà soát policy của OpenAI/Claude). |
| 3 | Nhật ký giám sát giao dịch/sử dụng bất thường | Chống Điều 324 BLHS (Case Pips) | ✗ CHƯA có | **Build ngay trong tuần này.** |
| 4 | DPIA / CTIA đã nộp | Tuân thủ PDPL Điều 30 | ✗ CHƯA có | Hoàn thành nộp trong 60 ngày kể từ khi tích hợp luồng log đầu tiên. |
| 5 | Phê duyệt nội dung marketing | Chống Điều 198 BLHS | ✓ ĐÃ có | Đã làm tại file `marketing_claims_audit.md`. |

## 2. Chọn TOP 1 ưu tiên
**Loại rủi ro cao nhất được chọn:** **[#3] Nhật ký giám sát giao dịch/sử dụng bất thường.**

**Lý do (1 câu):** 
Giống như Ngân Lượng bị liên đới tội rửa tiền vì cung cấp hạ tầng thanh toán cho sàn lừa đảo, TrustGuard là "hạ tầng kiểm duyệt AI"; nếu hệ thống phát hiện log của khách hàng có chứa hành vi lừa đảo/phi pháp mà ta nhắm mắt làm ngơ tiếp tục cung cấp dịch vụ (vì hợp đồng $50k/năm), Founder sẽ bị khởi tố Điều 324.

## 3. Hành động 1 tuần (Dành cho TOP 1)
- **Người chịu trách nhiệm:** Hoàng Quang Thắng (Founder) phối hợp cùng CISO nội bộ.
- **Tần suất cập nhật:** Hằng tuần (Weekly review các cờ cảnh báo đỏ từ hệ thống).
- **Template tài liệu sẽ xây (Mẫu 4 dòng):**

> **[Ngày/Giờ cảnh báo]:** 15/05/2026 - 10:30 AM
> **[Tenant/Khách hàng]:** Enterprise_Client_02
> **[Dấu hiệu rủi ro (Nghi ngờ Điều 324)]:** TrustGuard quét log phát hiện AI nội bộ của khách hàng tạo ra số lượng lớn kịch bản tư vấn kêu gọi đầu tư lợi nhuận cao bất thường (có dấu hiệu đa cấp/Ponzi).
> **[Hành động thẩm định của TrustGuard]:** Chủ động đóng băng luồng API Fast-track cho dự án AI này. Đã gửi văn bản chính thức yêu cầu bộ phận Compliance của khách hàng giải trình trước khi mở lại dịch vụ.
> **[Chữ ký Founder]:** (Đã ký)
